<?php
// Hengyi Li
$db_host = '150.243.199.158:3306';
$db_user = 'hl3265';
$db_pass = 'silverhandMiles710#';
$db_db = 'hl3265';
?>
