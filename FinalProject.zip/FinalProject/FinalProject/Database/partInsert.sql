use hl3265;
insert into part (part) values ('adjective');
insert into part (part) values ('adverb');
insert into part (part) values ('noun');
insert into part (part) values ('verb');
